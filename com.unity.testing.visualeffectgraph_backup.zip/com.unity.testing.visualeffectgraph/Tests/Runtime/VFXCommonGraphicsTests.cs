namespace UnityEngine.VFX.Test
{
    public class VFXCommonGraphicsTests
    {
        static public bool toto = true;
    }
}
